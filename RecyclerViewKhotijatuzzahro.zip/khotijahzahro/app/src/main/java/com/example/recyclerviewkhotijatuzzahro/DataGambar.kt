package com.example.recyclerviewkhotijatuzzahro

data class DataGambar (val gambar: Int ,val title: String,val harga:String)
